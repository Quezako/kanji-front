(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["modules-tabs-tabs-module"],{

/***/ "./src/app/core/services/api.service.ts":
/*!**********************************************!*\
  !*** ./src/app/core/services/api.service.ts ***!
  \**********************************************/
/*! exports provided: ApiService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiService", function() { return ApiService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var apiUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].apiUrl;
var ApiService = /** @class */ (function () {
    function ApiService(http) {
        this.http = http;
    }
    ApiService.prototype.handleError = function (operation, result) {
        if (operation === void 0) { operation = 'operation'; }
        return function (error) {
            console.error(error);
            // Let the app keep running by returning an empty result.
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(result);
        };
    };
    ApiService.prototype.extractData = function (res) {
        var body = res;
        return body || {};
    };
    ApiService.prototype.getKanjis = function (api, params) {
        var url = apiUrl + "/" + api + "?" + params;
        console.log(url);
        return this.http.get(url, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(this.extractData), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError('getKanjis')));
    };
    ApiService.prototype.getKanji = function (id) {
        var url = apiUrl + "/chmn/?hanzi=" + id;
        console.log(url);
        return this.http.get(url).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (_) { return console.log("fetched kanji id=" + id); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError("getKanji id=" + id)));
    };
    ApiService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], ApiService);
    return ApiService;
}());



/***/ }),

/***/ "./src/app/modules/about/about.module.ts":
/*!***********************************************!*\
  !*** ./src/app/modules/about/about.module.ts ***!
  \***********************************************/
/*! exports provided: AboutPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutPageModule", function() { return AboutPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _about_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./about.page */ "./src/app/modules/about/about.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _about_page__WEBPACK_IMPORTED_MODULE_5__["AboutPage"]
    }
];
var AboutPageModule = /** @class */ (function () {
    function AboutPageModule() {
    }
    AboutPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_about_page__WEBPACK_IMPORTED_MODULE_5__["AboutPage"]]
        })
    ], AboutPageModule);
    return AboutPageModule;
}());



/***/ }),

/***/ "./src/app/modules/about/about.page.html":
/*!***********************************************!*\
  !*** ./src/app/modules/about/about.page.html ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>About</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n      <ion-list>\n        <ion-item-divider>Kanji Mnemonics</ion-item-divider>\n        <ion-item>\n          Designed and developed by Jonathan Mousserion.\n          <a href=\"https://quezako.com\"><ion-icon name=\"link\"></ion-icon></a>\n        </ion-item>\n        <ion-item>\n          This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.\n        </ion-item>\n        <ion-item-divider>Data sources</ion-item-divider>\n        <ion-item>\n          Mnemonics and full database by Reinaert Albrecht.\n          <a href=\"http://www.rtega.be/chmn/\"><ion-icon name=\"link\"></ion-icon></a>\n        </ion-item>\n        <ion-item>\n          Kanji data from Kanjidic by Jim Breen.\n          <a href=\"http://www.edrdg.org/wiki/index.php/KANJIDIC_Project\"><ion-icon name=\"link\"></ion-icon></a>\n        </ion-item>\n        <ion-item>\n          The SKIP system for ordering kanji was developed by Jack Halpern.\n          <a href=\"http://www.kanji.org/\"><ion-icon name=\"link\"></ion-icon></a>\n        </ion-item>\n        <ion-item-divider>Libraries & Frameworks</ion-item-divider>\n        <ion-item>Back-end: CakePHP with MySQL.</ion-item>\n        <ion-item>Front-end: Angular 7, Ionic 4.</ion-item>\n        <ion-item>Mobile app: Apache Cordova 8.</ion-item>\n        </ion-list>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/modules/about/about.page.scss":
/*!***********************************************!*\
  !*** ./src/app/modules/about/about.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".in-list {\n  --min-height: 0px;\n  font-size: 14px;\n  padding-top: 5px;\n  padding-bottom: 5px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbW9kdWxlcy9hYm91dC9EOlxcRGV2XFxrYW5qaS1tb2JpbGUvc3JjXFxhcHBcXG1vZHVsZXNcXGFib3V0XFxhYm91dC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxpQkFBYTtFQUNiLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsbUJBQW1CLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9tb2R1bGVzL2Fib3V0L2Fib3V0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5pbi1saXN0IHtcclxuICAgIC0tbWluLWhlaWdodDogMHB4O1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgcGFkZGluZy10b3A6IDVweDtcclxuICAgIHBhZGRpbmctYm90dG9tOiA1cHg7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/modules/about/about.page.ts":
/*!*********************************************!*\
  !*** ./src/app/modules/about/about.page.ts ***!
  \*********************************************/
/*! exports provided: AboutPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutPage", function() { return AboutPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var AboutPage = /** @class */ (function () {
    function AboutPage() {
    }
    AboutPage.prototype.ngOnInit = function () {
    };
    AboutPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-about',
            template: __webpack_require__(/*! ./about.page.html */ "./src/app/modules/about/about.page.html"),
            styles: [__webpack_require__(/*! ./about.page.scss */ "./src/app/modules/about/about.page.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], AboutPage);
    return AboutPage;
}());



/***/ }),

/***/ "./src/app/modules/details/details.module.ts":
/*!***************************************************!*\
  !*** ./src/app/modules/details/details.module.ts ***!
  \***************************************************/
/*! exports provided: DetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailsPageModule", function() { return DetailsPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _details_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./details.page */ "./src/app/modules/details/details.page.ts");
/* harmony import */ var _shared_pipes_sanitize_html_pipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/pipes/sanitize-html.pipe */ "./src/app/shared/pipes/sanitize-html.pipe.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var routes = [
    {
        path: '',
        component: _details_page__WEBPACK_IMPORTED_MODULE_5__["DetailsPage"]
    }
];
var DetailsPageModule = /** @class */ (function () {
    function DetailsPageModule() {
    }
    DetailsPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [
                _details_page__WEBPACK_IMPORTED_MODULE_5__["DetailsPage"],
                _shared_pipes_sanitize_html_pipe__WEBPACK_IMPORTED_MODULE_6__["SanitizeHtmlPipe"]
            ]
        })
    ], DetailsPageModule);
    return DetailsPageModule;
}());



/***/ }),

/***/ "./src/app/modules/details/details.page.html":
/*!***************************************************!*\
  !*** ./src/app/modules/details/details.page.html ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"home\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>\r\n      <span *ngIf=\"kanjis[0] !== undefined\">\r\n        <span *ngFor=\"let kanji of kanjis\" class=\"kanji\">\r\n          {{kanji.hanzi}}\r\n        </span>\r\n      </span>\r\n    </ion-title>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button routerLink=\"/\">\r\n        <ion-icon slot=\"icon-only\" name=\"home\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content *ngIf=\"!noresult\">\r\n\r\n  <ion-card *ngFor=\"let kanji of kanjis\">\r\n    <ion-card-content>\r\n      <div>\r\n        <span class=\"kanji\">\r\n          {{kanji.hanzi}}\r\n          {{kanji.simplified}}\r\n        </span>\r\n        <span [innerHTML]=\"kanji.meaning | sanitizeHtml\"></span>\r\n      </div>\r\n\r\n      <div style=\"background: #e8f0ff;\" *ngIf=\"kanji.mnemonics[0] !== undefined\">\r\n        <ion-item lines=\"none\" color=\"transparent\">\r\n          <ion-icon name=\"flask\" size=\"small\" color=\"primary\"></ion-icon>\r\n          <ion-label>Mnemonics</ion-label>\r\n        </ion-item>\r\n          <span *ngFor=\"let mnemonic of kanji.mnemonics\">\r\n            <span *ngIf=\"mnemonic.length > 1\" [innerHTML]=\"mnemonic | sanitizeHtml\"></span>\r\n            <a *ngIf=\"mnemonic.length == 1\" routerLink=\"/details/{{mnemonic}}\">{{mnemonic}}</a>\r\n          </span>\r\n      </div>\r\n\r\n      <div style=\"background: #e1fdff;\" *ngIf=\"kanji.simplified\">\r\n        <ion-item lines=\"none\" color=\"transparent\">\r\n          <ion-icon name=\"cut\" size=\"small\" color=\"secondary\"></ion-icon>\r\n          <ion-label>Simplified</ion-label>\r\n        </ion-item>\r\n        <p>{{kanji.simplified}}</p>\r\n      </div>\r\n\r\n      <div style=\"background: #eee8ff;\" *ngIf=\"kanji.alike[1] !== undefined\">\r\n        <ion-item lines=\"none\" color=\"transparent\">\r\n          <ion-icon name=\"swap\" size=\"small\" color=\"tertiary\"></ion-icon>\r\n          <ion-label>Alike</ion-label>\r\n        </ion-item>\r\n        <span *ngFor=\"let alike of kanji.alike\">\r\n          <span *ngIf=\"alike.length > 1\" [innerHTML]=\"alike | sanitizeHtml\"></span>\r\n          <a *ngIf=\"alike.length == 1\" routerLink=\"/details/{{alike}}\">{{alike}}</a>\r\n        </span>\r\n      </div>\r\n\r\n      <div style=\"background: #eafff3;\" *ngIf=\"kanji.reference[1] !== undefined\">\r\n        <ion-item lines=\"none\" color=\"transparent\">\r\n          <ion-icon name=\"book\" size=\"small\" color=\"success\"></ion-icon>\r\n          <ion-label>Reference</ion-label>\r\n        </ion-item>\r\n        <span *ngFor=\"let reference of kanji.reference\">\r\n          <span *ngIf=\"reference.length > 1\" [innerHTML]=\"reference | sanitizeHtml\"></span>\r\n          <a *ngIf=\"reference.length == 1\" routerLink=\"/details/{{reference}}\">{{reference}}</a>\r\n        </span>\r\n      </div>\r\n\r\n    </ion-card-content>\r\n  </ion-card>\r\n\r\n</ion-content>\r\n\r\n<ion-content *ngIf=\"!kanjis['init'] && noresult\">\r\n  <ion-card color=\"warning\">\r\n    <ion-card-content>\r\n      This Kanji has no mnemonic.<br />\r\n      Look up <span class=\"kanji\">{{id}}</span> with <a href=\"https://en.wiktionary.org/wiki/{{id}}\">wiktionary</a>.\r\n    </ion-card-content>\r\n  </ion-card>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/modules/details/details.page.scss":
/*!***************************************************!*\
  !*** ./src/app/modules/details/details.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "h1 {\n  margin-top: 0px;\n  margin-right: 10px; }\n\np {\n  font-size: 120%; }\n\n.kanji {\n  font-size: 200%;\n  margin-right: 5px; }\n\n.item-lines-none {\n  --min-height: 0px; }\n\n.item-lines-none * {\n  margin: 5px;\n  padding: 0; }\n\ndiv {\n  border-radius: 2px;\n  padding: 5px;\n  margin-bottom: 5px; }\n\na {\n  text-decoration: none;\n  font-size: 16px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbW9kdWxlcy9kZXRhaWxzL0Q6XFxEZXZcXGthbmppLW1vYmlsZS9zcmNcXGFwcFxcbW9kdWxlc1xcZGV0YWlsc1xcZGV0YWlscy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxlQUFlO0VBQ2Ysa0JBQWtCLEVBQUE7O0FBR3RCO0VBQ0ksZUFBZSxFQUFBOztBQUduQjtFQUNFLGVBQWU7RUFDZixpQkFBaUIsRUFBQTs7QUFHbkI7RUFDSSxpQkFBYSxFQUFBOztBQUdqQjtFQUNJLFdBQVc7RUFDWCxVQUFVLEVBQUE7O0FBR2Q7RUFDSSxrQkFBa0I7RUFDbEIsWUFBWTtFQUNaLGtCQUFrQixFQUFBOztBQUd0QjtFQUNJLHFCQUFxQjtFQUNyQixlQUFlLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9tb2R1bGVzL2RldGFpbHMvZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJoMSB7XHJcbiAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbn1cclxuXHJcbnAge1xyXG4gICAgZm9udC1zaXplOiAxMjAlO1xyXG59XHJcblxyXG4ua2Fuamkge1xyXG4gIGZvbnQtc2l6ZTogMjAwJTtcclxuICBtYXJnaW4tcmlnaHQ6IDVweDtcclxufVxyXG5cclxuLml0ZW0tbGluZXMtbm9uZSB7XHJcbiAgICAtLW1pbi1oZWlnaHQ6IDBweDtcclxufVxyXG5cclxuLml0ZW0tbGluZXMtbm9uZSAqIHtcclxuICAgIG1hcmdpbjogNXB4O1xyXG4gICAgcGFkZGluZzogMDtcclxufVxyXG5cclxuZGl2IHtcclxuICAgIGJvcmRlci1yYWRpdXM6IDJweDtcclxuICAgIHBhZGRpbmc6IDVweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDVweDtcclxufVxyXG5cclxuYSB7XHJcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/modules/details/details.page.ts":
/*!*************************************************!*\
  !*** ./src/app/modules/details/details.page.ts ***!
  \*************************************************/
/*! exports provided: DetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailsPage", function() { return DetailsPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _core_services_api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../core/services/api.service */ "./src/app/core/services/api.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};




var DetailsPage = /** @class */ (function () {
    function DetailsPage(api, loadingController, route, router, alertController) {
        this.api = api;
        this.loadingController = loadingController;
        this.route = route;
        this.router = router;
        this.alertController = alertController;
        this.kanjis = {
            'init': '0',
        };
        this.id = this.route.snapshot.paramMap.get('id');
        this.noresult = true;
    }
    DetailsPage.prototype.ngOnInit = function () {
        this.getKanji();
    };
    DetailsPage.prototype.getKanji = function () {
        return __awaiter(this, void 0, void 0, function () {
            var loading_1;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!(this.id == 'null')) return [3 /*break*/, 1];
                        this.presentAlertConfirm('You are not choosing an item from the list');
                        return [3 /*break*/, 5];
                    case 1: return [4 /*yield*/, this.loadingController.create({
                            message: 'Loading...'
                        })];
                    case 2:
                        loading_1 = _a.sent();
                        return [4 /*yield*/, loading_1.present()];
                    case 3:
                        _a.sent();
                        return [4 /*yield*/, this.api.getKanji(this.id)
                                .subscribe(function (res) {
                                console.log(res);
                                if (res.result.chmn[0].label === null) {
                                    _this.noresult = true;
                                    _this.kanjis = {};
                                }
                                else {
                                    _this.noresult = false;
                                    res.result.chmn.forEach(function (kanji) {
                                        for (var field in kanji) {
                                            if (['mnemonics', 'alike', 'reference'].includes(field)) {
                                                kanji[field] = kanji[field].replace(/; /g, ";<br>");
                                                kanji[field] = kanji[field].replace(/<i>(.*?)<\/i>/g, "<span style='color: #f0808f;'>$1</span>");
                                                kanji[field] = kanji[field].replace(/<a href=("|')\?d=(.*?)("|')>/gi, "<a href='http://nihongo.monash.edu/cgi-bin/wwwjdic?1MKDR$2'>");
                                                kanji[field] = kanji[field].replace(/<(img|a c=".") (svg)=("|')(.*?)("|')>/gi, "<img src='assets/img/$4.$2' style='height: 16px;width:auto;display: inline;'>");
                                                // Split the field in array for each kanji found in text.
                                                // Then template will add a link to each kanji (unique caractere on 1 line).
                                                kanji[field] = kanji[field].split(/(\p{Script=Hani})+/gu);
                                            }
                                        }
                                    });
                                    _this.kanjis = res.result.chmn;
                                }
                                console.log(_this.noresult);
                                loading_1.dismiss();
                            }, function (err) {
                                console.log(err);
                                loading_1.dismiss();
                            })];
                    case 4:
                        _a.sent();
                        _a.label = 5;
                    case 5: return [2 /*return*/];
                }
            });
        });
    };
    DetailsPage.prototype.presentAlertConfirm = function (msg) {
        return __awaiter(this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'Warning!',
                            message: msg,
                            buttons: [
                                {
                                    text: 'Okay',
                                    handler: function () {
                                        _this.router.navigate(['']);
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    DetailsPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-details',
            template: __webpack_require__(/*! ./details.page.html */ "./src/app/modules/details/details.page.html"),
            styles: [__webpack_require__(/*! ./details.page.scss */ "./src/app/modules/details/details.page.scss")]
        }),
        __metadata("design:paramtypes", [_core_services_api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]])
    ], DetailsPage);
    return DetailsPage;
}());



/***/ }),

/***/ "./src/app/modules/home/home.module.ts":
/*!*********************************************!*\
  !*** ./src/app/modules/home/home.module.ts ***!
  \*********************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/cdk/scrolling */ "./node_modules/@angular/cdk/esm5/scrolling.es5.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/modules/home/home.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]
    }
];
var HomePageModule = /** @class */ (function () {
    function HomePageModule() {
    }
    HomePageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_4__["ScrollingModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
        })
    ], HomePageModule);
    return HomePageModule;
}());



/***/ }),

/***/ "./src/app/modules/home/home.page.html":
/*!*********************************************!*\
  !*** ./src/app/modules/home/home.page.html ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n\r\n  <ion-toolbar color=\"dark\">\r\n    <ion-segment>\r\n    </ion-segment>\r\n  </ion-toolbar>\r\n\r\n  <ion-toolbar>\r\n    <ion-searchbar [formControl]=\"findControl\" placeholder=\"Meaning\" size=\"small\"></ion-searchbar>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button routerLink=\"/about\">\r\n        <ion-icon slot=\"icon-only\" name=\"information-circle-outline\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n\r\n  <ion-toolbar color=\"light\" (ionChange)=\"segmentChanged($event)\">\r\n    <ion-segment>\r\n      <ion-segment-button checked=\"true\">\r\n        <ion-label>Meaning</ion-label>\r\n      </ion-segment-button>\r\n      <ion-segment-button>\r\n        <ion-label>ON read</ion-label>\r\n      </ion-segment-button>\r\n      <ion-segment-button>\r\n        <ion-label>KUN read</ion-label>\r\n      </ion-segment-button>\r\n      <ion-segment-button>\r\n        <ion-label>Kanji</ion-label>\r\n      </ion-segment-button>\r\n      <ion-segment-button>\r\n        <ion-label>Radicals</ion-label>\r\n      </ion-segment-button>\r\n    </ion-segment>\r\n  </ion-toolbar>\r\n\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div class=\"loader\" *ngIf=\"loading && findControl.value && findControl.value.length > 0\">\r\n    <div class=\"center\">\r\n      <img src=\"assets/animated_spinner.gif\" style=\"height: 25px;padding-right: 5px;\" /> Loading...\r\n    </div>\r\n  </div>\r\n\r\n  <cdk-virtual-scroll-viewport cdkDropList style=\"height: 100%\" itemSize=\"20\" class=\"example-viewport\" minBufferPx=\"1200\" maxBufferPx=\"1200\">\r\n\r\n    <div *ngIf=\"!noresult && findControl.value && findControl.value.length > 0\">\r\n        <ion-item *ngFor=\"let kanji of kanjis\" routerLink=\"/details/{{kanji.ucs}}\">\r\n        <ion-label text-wrap>\r\n          {{kanji.ucs}}\r\n          {{kanji.label}}\r\n        </ion-label>\r\n      </ion-item>\r\n    </div>\r\n\r\n    <ion-item *ngIf=\"noresult && findControl.value && findControl.value.length > 0\" color=\"warning\">\r\n      No result\r\n    </ion-item>\r\n\r\n    <ion-item *ngIf=\"error\" color=\"danger\">\r\n      Communication error with the server, please try again.\r\n    </ion-item>\r\n\r\n  </cdk-virtual-scroll-viewport>\r\n\r\n</ion-content>"

/***/ }),

/***/ "./src/app/modules/home/home.page.scss":
/*!*********************************************!*\
  !*** ./src/app/modules/home/home.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  padding: 0;\n  min-height: 20px; }\n\nion-segment-button, ion-label {\n  margin-top: 2px;\n  margin-bottom: 2px;\n  min-height: 0;\n  margin: 0;\n  padding: 0;\n  --padding-end: 0;\n  --padding-start: 0;\n  text-transform: initial;\n  min-width: 0;\n  font-size: 13px; }\n\nion-segment-button {\n  border-right: 1px #ddd solid; }\n\nion-segment-button:last-child {\n  border-right: 0; }\n\nion-item ion-label {\n  margin-top: 5px;\n  margin-bottom: 5px; }\n\nion-item ion-label::first-letter {\n  font-size: 200%;\n  margin-right: 5px; }\n\n.loader {\n  width: auto;\n  height: auto;\n  padding: auto;\n  background: rgba(230, 230, 230, 0.75);\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  margin: auto;\n  z-index: 999; }\n\n.center {\n  width: 120px;\n  height: 35px;\n  padding: 5px;\n  background: #fff;\n  position: absolute;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  margin: auto;\n  z-index: 1000; }\n\n.center * {\n  vertical-align: middle; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbW9kdWxlcy9ob21lL0Q6XFxEZXZcXGthbmppLW1vYmlsZS9zcmNcXGFwcFxcbW9kdWxlc1xcaG9tZVxcaG9tZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxVQUFVO0VBQ1YsZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksZUFBZTtFQUNmLGtCQUFrQjtFQUNsQixhQUFhO0VBQ2IsU0FBUztFQUNULFVBQVU7RUFDVixnQkFBYztFQUNkLGtCQUFnQjtFQUNoQix1QkFBdUI7RUFDdkIsWUFBWTtFQUNaLGVBQWUsRUFBQTs7QUFHbkI7RUFDRSw0QkFBNEIsRUFBQTs7QUFHOUI7RUFDRSxlQUFlLEVBQUE7O0FBR2pCO0VBQ0ksZUFBZTtFQUNmLGtCQUFrQixFQUFBOztBQUd0QjtFQUNFLGVBQWU7RUFDZixpQkFBaUIsRUFBQTs7QUFHbkI7RUFDQyxXQUFXO0VBQ1YsWUFBWTtFQUNaLGFBQWE7RUFDYixxQ0FBb0M7RUFFckMsa0JBQWtCO0VBQ2xCLE1BQUs7RUFDTCxTQUFTO0VBQ1QsT0FBTztFQUNQLFFBQVE7RUFFUCxZQUFZO0VBQ1osWUFBWSxFQUFBOztBQUdkO0VBQ0MsWUFBWTtFQUNYLFlBQVk7RUFDWixZQUFZO0VBQ1osZ0JBQWdCO0VBRWpCLGtCQUFrQjtFQUNsQixNQUFLO0VBQ0wsU0FBUztFQUNULE9BQU87RUFDUCxRQUFRO0VBRVAsWUFBWTtFQUNaLGFBQWEsRUFBQTs7QUFJZjtFQUNFLHNCQUFzQixFQUFBIiwiZmlsZSI6InNyYy9hcHAvbW9kdWxlcy9ob21lL2hvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXIge1xyXG4gICAgcGFkZGluZzogMDtcclxuICAgIG1pbi1oZWlnaHQ6IDIwcHg7XHJcbn1cclxuXHJcbmlvbi1zZWdtZW50LWJ1dHRvbiwgaW9uLWxhYmVsIHtcclxuICAgIG1hcmdpbi10b3A6IDJweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDJweDtcclxuICAgIG1pbi1oZWlnaHQ6IDA7XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG4gICAgLS1wYWRkaW5nLWVuZDogMDtcclxuICAgIC0tcGFkZGluZy1zdGFydDogMDtcclxuICAgIHRleHQtdHJhbnNmb3JtOiBpbml0aWFsO1xyXG4gICAgbWluLXdpZHRoOiAwO1xyXG4gICAgZm9udC1zaXplOiAxM3B4O1xyXG59XHJcblxyXG5pb24tc2VnbWVudC1idXR0b24ge1xyXG4gIGJvcmRlci1yaWdodDogMXB4ICNkZGQgc29saWQ7XHJcbn1cclxuXHJcbmlvbi1zZWdtZW50LWJ1dHRvbjpsYXN0LWNoaWxkIHtcclxuICBib3JkZXItcmlnaHQ6IDA7XHJcbn1cclxuXHJcbmlvbi1pdGVtIGlvbi1sYWJlbCB7XHJcbiAgICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiA1cHg7XHJcbn1cclxuXHJcbmlvbi1pdGVtIGlvbi1sYWJlbDo6Zmlyc3QtbGV0dGVyIHtcclxuICBmb250LXNpemU6IDIwMCU7XHJcbiAgbWFyZ2luLXJpZ2h0OiA1cHg7XHJcbn1cclxuXHJcbi5sb2FkZXIge1xyXG5cdHdpZHRoOiBhdXRvO1xyXG4gIGhlaWdodDogYXV0bztcclxuICBwYWRkaW5nOiBhdXRvO1xyXG4gIGJhY2tncm91bmQ6IHJnYmEoMjMwLCAyMzAsIDIzMCwgLjc1KTtcclxuXHJcblx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdHRvcDowO1xyXG5cdGJvdHRvbTogMDtcclxuXHRsZWZ0OiAwO1xyXG5cdHJpZ2h0OiAwO1xyXG5cclxuICBtYXJnaW46IGF1dG87XHJcbiAgei1pbmRleDogOTk5O1xyXG59XHJcblxyXG4uY2VudGVyIHtcclxuXHR3aWR0aDogMTIwcHg7XHJcbiAgaGVpZ2h0OiAzNXB4O1xyXG4gIHBhZGRpbmc6IDVweDtcclxuICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG5cclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0dG9wOjA7XHJcblx0Ym90dG9tOiAwO1xyXG5cdGxlZnQ6IDA7XHJcblx0cmlnaHQ6IDA7XHJcblxyXG4gIG1hcmdpbjogYXV0bztcclxuICB6LWluZGV4OiAxMDAwO1xyXG59XHJcblxyXG5cclxuLmNlbnRlciAqIHtcclxuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/modules/home/home.page.ts":
/*!*******************************************!*\
  !*** ./src/app/modules/home/home.page.ts ***!
  \*******************************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _core_services_api_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../core/services/api.service */ "./src/app/core/services/api.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var HomePage = /** @class */ (function () {
    function HomePage(apiService, route, router) {
        this.apiService = apiService;
        this.route = route;
        this.router = router;
        this.kanjis = [
            [
                {
                    'hanzi': null,
                }
            ],
        ];
        this.findControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]();
        this.error = false;
        this.noresult = false;
        this.loading = false;
        this.objApi = {
            'ion-sb-0': 'kanji-meanings',
            'ion-sb-1': 'kanji-readings',
            'ion-sb-2': 'kanji-readings',
            'ion-sb-3': 'chmn',
            'ion-sb-4': 'ids',
        };
        this.objField = {
            'ion-sb-0': 'meaning',
            'ion-sb-1': 'reading',
            'ion-sb-2': 'reading',
            'ion-sb-3': 'hanzi',
            'ion-sb-4': 'ids',
        };
        this.objField2 = {
            'ion-sb-0': 'language=en',
            'ion-sb-1': 'type=ja_on',
            'ion-sb-2': 'type=ja_kun',
            'ion-sb-3': '',
            'ion-sb-4': '',
        };
        this.objJson = {
            'ion-sb-0': 'kanjiMeanings',
            'ion-sb-1': 'kanjiReadings',
            'ion-sb-2': 'kanjiReadings',
            'ion-sb-3': 'chmn',
            'ion-sb-4': 'ids',
        };
        this.api = this.objApi['ion-sb-0'];
        this.field = this.objField['ion-sb-0'];
        this.field2 = this.objField2['ion-sb-0'];
        this.json = this.objJson['ion-sb-0'];
        this.params = this.field2 + "&" + this.field + "=";
    }
    HomePage.prototype.ngOnInit = function () {
        var _this = this;
        this.findControl.valueChanges
            .subscribe(function (kanjis) {
            _this.noresult = false;
            _this.loading = true;
        });
        this.findControl.valueChanges
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["filter"])(function (value) { return value.length > 0; }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["debounceTime"])(1000), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["switchMap"])(function (value) {
            return _this.apiService.getKanjis(_this.api, _this.params + value).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(function (err) {
                _this.kanjis = null;
                _this.error = true;
                _this.loading = false;
                console.log('error');
                return rxjs__WEBPACK_IMPORTED_MODULE_4__["EMPTY"];
            }));
        }))
            .subscribe(function (kanjis) {
            _this.noresult = false;
            _this.loading = false;
            if (kanjis) {
                _this.error = false;
                // console.log(kanjis.result[this.json]);
                _this.kanjis = kanjis.result[_this.json];
                console.log(_this.kanjis);
                if (kanjis.result[_this.json].length == 0) {
                    _this.noresult = true;
                }
                else if (kanjis.result[_this.json][0].label === null) {
                    _this.noresult = true;
                }
            }
            else {
                _this.kanjis = null;
                _this.error = true;
                return rxjs__WEBPACK_IMPORTED_MODULE_4__["EMPTY"];
            }
        });
    };
    HomePage.prototype.segmentChanged = function (segment) {
        this.noresult = false;
        this.api = this.objApi[segment.detail.value];
        this.field = this.objField[segment.detail.value];
        this.field2 = this.objField2[segment.detail.value];
        this.json = this.objJson[segment.detail.value];
        this.params = this.field + "=";
        if (this.field2 != '') {
            this.params = this.field2 + "&" + this.field + "=";
        }
        if (this.findControl.value && this.findControl.value.length != 0) {
            this.findControl.setValue(this.findControl.value);
        }
    };
    HomePage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! ./home.page.html */ "./src/app/modules/home/home.page.html"),
            styles: [__webpack_require__(/*! ./home.page.scss */ "./src/app/modules/home/home.page.scss")]
        }),
        __metadata("design:paramtypes", [_core_services_api_service__WEBPACK_IMPORTED_MODULE_5__["ApiService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])
    ], HomePage);
    return HomePage;
}());



/***/ }),

/***/ "./src/app/modules/tabs/tabs.module.ts":
/*!*********************************************!*\
  !*** ./src/app/modules/tabs/tabs.module.ts ***!
  \*********************************************/
/*! exports provided: TabsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPageModule", function() { return TabsPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _tabs_router_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./tabs.router.module */ "./src/app/modules/tabs/tabs.router.module.ts");
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tabs.page */ "./src/app/modules/tabs/tabs.page.ts");
/* harmony import */ var _home_home_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../home/home.module */ "./src/app/modules/home/home.module.ts");
/* harmony import */ var _details_details_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../details/details.module */ "./src/app/modules/details/details.module.ts");
/* harmony import */ var _about_about_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../about/about.module */ "./src/app/modules/about/about.module.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};









var TabsPageModule = /** @class */ (function () {
    function TabsPageModule() {
    }
    TabsPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _tabs_router_module__WEBPACK_IMPORTED_MODULE_4__["TabsPageRoutingModule"],
                _home_home_module__WEBPACK_IMPORTED_MODULE_6__["HomePageModule"],
                _details_details_module__WEBPACK_IMPORTED_MODULE_7__["DetailsPageModule"],
                _about_about_module__WEBPACK_IMPORTED_MODULE_8__["AboutPageModule"]
            ],
            declarations: [_tabs_page__WEBPACK_IMPORTED_MODULE_5__["TabsPage"]]
        })
    ], TabsPageModule);
    return TabsPageModule;
}());



/***/ }),

/***/ "./src/app/modules/tabs/tabs.page.html":
/*!*********************************************!*\
  !*** ./src/app/modules/tabs/tabs.page.html ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/modules/tabs/tabs.page.scss":
/*!*********************************************!*\
  !*** ./src/app/modules/tabs/tabs.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21vZHVsZXMvdGFicy90YWJzLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/modules/tabs/tabs.page.ts":
/*!*******************************************!*\
  !*** ./src/app/modules/tabs/tabs.page.ts ***!
  \*******************************************/
/*! exports provided: TabsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPage", function() { return TabsPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var TabsPage = /** @class */ (function () {
    function TabsPage() {
    }
    TabsPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-tabs',
            template: __webpack_require__(/*! ./tabs.page.html */ "./src/app/modules/tabs/tabs.page.html"),
            styles: [__webpack_require__(/*! ./tabs.page.scss */ "./src/app/modules/tabs/tabs.page.scss")]
        })
    ], TabsPage);
    return TabsPage;
}());



/***/ }),

/***/ "./src/app/modules/tabs/tabs.router.module.ts":
/*!****************************************************!*\
  !*** ./src/app/modules/tabs/tabs.router.module.ts ***!
  \****************************************************/
/*! exports provided: TabsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPageRoutingModule", function() { return TabsPageRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _home_home_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../home/home.page */ "./src/app/modules/home/home.page.ts");
/* harmony import */ var _details_details_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../details/details.page */ "./src/app/modules/details/details.page.ts");
/* harmony import */ var _about_about_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../about/about.page */ "./src/app/modules/about/about.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var routes = [
    { path: '', redirectTo: '/home', pathMatch: 'full' },
    { path: 'home', component: _home_home_page__WEBPACK_IMPORTED_MODULE_2__["HomePage"] },
    { path: 'details/:id', component: _details_details_page__WEBPACK_IMPORTED_MODULE_3__["DetailsPage"] },
    { path: 'about', component: _about_about_page__WEBPACK_IMPORTED_MODULE_4__["AboutPage"] },
];
var TabsPageRoutingModule = /** @class */ (function () {
    function TabsPageRoutingModule() {
    }
    TabsPageRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild(routes)
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], TabsPageRoutingModule);
    return TabsPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/shared/pipes/sanitize-html.pipe.ts":
/*!****************************************************!*\
  !*** ./src/app/shared/pipes/sanitize-html.pipe.ts ***!
  \****************************************************/
/*! exports provided: SanitizeHtmlPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SanitizeHtmlPipe", function() { return SanitizeHtmlPipe; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var SanitizeHtmlPipe = /** @class */ (function () {
    function SanitizeHtmlPipe(sanitizer) {
        this.sanitizer = sanitizer;
    }
    SanitizeHtmlPipe.prototype.transform = function (value) {
        return this.sanitizer.bypassSecurityTrustHtml(value);
    };
    SanitizeHtmlPipe = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"])({
            name: 'sanitizeHtml'
        }),
        __metadata("design:paramtypes", [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["DomSanitizer"]])
    ], SanitizeHtmlPipe);
    return SanitizeHtmlPipe;
}());



/***/ })

}]);
//# sourceMappingURL=modules-tabs-tabs-module.js.map